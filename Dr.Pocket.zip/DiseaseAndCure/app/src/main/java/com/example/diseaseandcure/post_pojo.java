package com.example.diseaseandcure;

public class post_pojo {

    private String res1;
    private String res2;
    private String res3;


    // Getter Methods

    public String getRes1()
    {
        return res1;
    }

    public String getRes2() {
        return res2;
    }

    public String getRes3() {
        return res3;
    }

    // Setter Methods

    public void setRes1(String res1) {
        this.res1 = res1;
    }

    public void setRes2(String res2) {
        this.res2 = res2;
    }

    public void setRes3(String res3) {
        this.res3 = res3;
    }
}
