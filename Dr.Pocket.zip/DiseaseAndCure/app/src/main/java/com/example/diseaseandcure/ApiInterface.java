package com.example.diseaseandcure;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiInterface {

    @GET("/aj/{word}")
    Call<List<post_pojo>> getposts(@Path("word") String abc);

}
