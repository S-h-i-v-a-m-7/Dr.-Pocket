package com.example.diseaseandcure;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Home extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    DrawerLayout drawerLayout;

    ApiInterface apiInterface;
    private Spinner spin1, spin2, spin3, spin4, spin5;
    private TextView t1, t2, t3, t4, t5, t6,t7;
    private String dis1, dis2, dis3;
    private Button btn, btn1, btn2;
    String[] res;

    //AutoCompleteTextView suggest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        drawerLayout = findViewById(R.id.drawer_layout);
//
//        if(!Python.isStarted()){
//            Python.start(new AndroidPlatform(this));
//        }
//
//        Python py = Python.getInstance();
//        PyObject pyobj = py.getModule("trail");

        apiInterface = RetrofitInstance.getRetrofit().create(ApiInterface.class);

//        drawerLayout = findViewById(R.id.drawer_layout);
        //  suggest = (AutoCompleteTextView)findViewById(R.id.suggestion);
        t1 = (TextView) findViewById(R.id.opinion1);
        t2 = (TextView) findViewById(R.id.opinion2);
        t3 = (TextView) findViewById(R.id.opinion3);
        t4 = (TextView)findViewById(R.id.med1);
        t5 = (TextView)findViewById(R.id.med2);
        t6 = (TextView)findViewById(R.id.med3);
        t7 = (TextView)findViewById(R.id.med4);
        spin1 = (Spinner) findViewById(R.id.spinner1);
        spin2 = (Spinner) findViewById(R.id.spinner2);
        spin3 = (Spinner) findViewById(R.id.spinner3);
        spin4 = (Spinner) findViewById(R.id.spinner4);
        spin5 = (Spinner) findViewById(R.id.spinner5);
        addItem();

        btn = (Button) findViewById(R.id.button);
        btn1 = (Button) findViewById(R.id.button4);
        btn2 = (Button) findViewById(R.id.button5);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TextView[] s = {t4,t5,t6,t7};




                if (res[0].equals("1")) {

                    Toast.makeText(Home.this, "Cannot Diagnose the disease, Consult the doctor..!", Toast.LENGTH_LONG).show();


                } else {
                    String b = "abc";
                    //s[0].setText(b);
                    for(int i=1; i<res.length; i++){
                        s[i-1].setText(res[i]);
                    }
                    Toast.makeText(Home.this, res[1] + "," + res[2] + "," + res[3], Toast.LENGTH_SHORT).show();

                }

                //Toast.makeText(Home.this,res[0], Toast.LENGTH_SHORT).show();

            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t1.setText("");
                t2.setText("");
                t3.setText("");
                t4.setText("");
                t5.setText("");
                t6.setText("");
                t7.setText("");
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sy = "", ab = "ajay";

                ArrayList<String> symptoms = new ArrayList<String>(5);
                //symptoms.set(1, spin1.getSelectedItem().toString());
                sy = sy + spin1.getSelectedItem().toString();
                //symptoms.set(2, spin2.getSelectedItem().toString());
                sy = sy + "," + spin2.getSelectedItem().toString();
                //symptoms.set(3, spin3.getSelectedItem().toString());
                sy = sy + "," + spin3.getSelectedItem().toString();
                //symptoms.set(4, spin4.getSelectedItem().toString());
                sy = sy + "," + spin4.getSelectedItem().toString();
                //symptoms.set(5, spin5.getSelectedItem().toString());
                sy = sy + "," + spin5.getSelectedItem().toString();

                apiInterface.getposts(sy).enqueue(new Callback<List<post_pojo>>() {
                    @Override
                    public void onResponse(Call<List<post_pojo>> call, Response<List<post_pojo>> response) {

                        if (response.body().size() > 0) {
//                                try {
//                                    JSONObject jsonObject = new JSONObject(response.body().toString());
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }
                            ArrayList<post_pojo> abcd = (ArrayList<post_pojo>) response.body();
                            Toast.makeText(Home.this, response.body().get(0).getRes1(), Toast.LENGTH_SHORT).show();
                            //log.d("sdbajba", response.body());


                            dis1 = abcd.get(0).getRes1();
                            dis2 = abcd.get(0).getRes2();
                            dis3 = abcd.get(0).getRes3();

                            String[] pred1, pred2, pred3;
                            pred1 = dis1.split(",");
                            pred2 = dis2.split(",");
                            pred3 = dis3.split(",");

                            t1.setText(pred1[0]);
                            t2.setText(pred2[0]);
                            t3.setText(pred3[0]);
                            //Toast.makeText(Home.this, pred1[0], Toast.LENGTH_SHORT).show();
                            //Toast.makeText(Home.this, pred2[0], Toast.LENGTH_SHORT).show();
                            //Toast.makeText(Home.this, pred3[0], Toast.LENGTH_SHORT).show();

                            if (pred1[0].equals(pred2[0])) {

                                res = pred1;

                            } else if (pred1[0].equals(pred3[0])) {

                                res = pred1;
                            } else if (pred2[0].equals(pred3[0])) {
                                res = pred2;
                            } else {
                                Toast.makeText(Home.this, "not found", Toast.LENGTH_SHORT).show();
                                res[0] = "1";
                            }

                        } else {
                            Toast.makeText(Home.this, "List is Empty..!", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<post_pojo>> call, Throwable t) {

                        Toast.makeText(Home.this, t.getLocalizedMessage(), Toast.LENGTH_LONG).show();

                    }
                });

//                    final PyObject obj  = pyobj.callAttr("main", sy);
//                    ab=obj.toString();
//                String[] res = ab.split(",");
//                    t1.setText(res[0]);
//                t2.setText(res[1]);
//                t3.setText(res[2]);
                //t2.setText(sy.toString());


            }
        });


    }



    private void addItem() {
        List<String> list = new ArrayList<String>();
        Scanner sc = new Scanner(getResources().openRawResource(R.raw.data_sympt));
        //sc.useDelimiter(",");
        while (sc.hasNext()) {
            list.add(sc.next());
        }
        sc.close();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        ArrayAdapter<String> newArray;
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        newArray = arrayAdapter;
        //  suggest.setAdapter(newArray);
        spin1.setAdapter(arrayAdapter);
        spin1.setOnItemSelectedListener(this);
        spin2.setAdapter(arrayAdapter);
        spin2.setOnItemSelectedListener(this);
        spin3.setAdapter(arrayAdapter);
        spin3.setOnItemSelectedListener(this);
        spin4.setAdapter(arrayAdapter);
        spin4.setOnItemSelectedListener(this);
        spin5.setAdapter(arrayAdapter);
        spin5.setOnItemSelectedListener(this);


//        try {
//            List<String> list = new ArrayList<String>();
//            // sc = new Scanner(new File("C:/Users/Rohit/AndroidStudioProjects/DiseaseAndCure/new_symptom.csv"));
//            Scanner sc = new Scanner(getResources().openRawResource(R.raw.new_symptom));
//            sc.useDelimiter(",");
//            String a;
//            while(sc.hasNext()){
//                a=sc.next();
//                list.add(a);
//            }
//            sc.close();
//            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
//            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//            spin1.setAdapter(arrayAdapter);
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }

//        List<String> list = new ArrayList<String>();
//        list.add("ajay");
//        list.add("jay");
//        list.add("om");
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
//           arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//         spin1.setAdapter(arrayAdapter);
//
    }

//
//    public void ClickMenu(View view){
//        openDrawer(drawerLayout);
//
//    }
//
//    public static void openDrawer(DrawerLayout drawerLayout) {
//        drawerLayout.openDrawer(GravityCompat.START);
//    }
//    public void ClickLogo(View view){
//        closeDrawer(drawerLayout);
//    }
//
//    public static void closeDrawer(DrawerLayout drawerLayout) {
//        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
//            drawerLayout.closeDrawer((GravityCompat.START));
//        }
//    }
//
//    public void ClickHome(View view){
//        recreate();
//    }
//
//    public void ClickDashboard(View view){
//        redirectActivity(this,Dashboard.class);
//    }
//    public void ClickAboutUs(View view){
//        redirectActivity(this,about_us.class);
//    }
//    public void ClickLogout(View view){
//        logout(this);
//    }
//
//    public static void logout(Activity activity) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setTitle("Logout");
//        builder.setMessage("Are you sure you want to logout ?");
//        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
//            @Override
//            public void onClick(DialogInterface dialog, int which){
//                activity.finishAffinity();
//                System.exit(0);
//            }
//        });
//        builder.setNegativeButton("No", new DialogInterface.OnClickListener(){
//            @Override
//            public void onClick(DialogInterface dialog ,int which){
//                dialog.dismiss();
//            }
//        });
//        builder.show();
//    }
//
//    public static void redirectActivity(Activity activity,Class aClass) {
//        Intent intent = new Intent(activity,aClass);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        activity.startActivity(intent);
//    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//        closeDrawer(drawerLayout);
//    }
//
//
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String sp1 = parent.getItemAtPosition(position).toString();
            //Toast.makeText(parent.getContext(), sp1, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void ClickMenu(View view){
        openDrawer(drawerLayout);

    }

    public static void openDrawer(DrawerLayout drawerLayout) {
        drawerLayout.openDrawer(GravityCompat.START);
    }
    public void ClickLogo(View view){
        closeDrawer(drawerLayout);
    }

    public static void closeDrawer(DrawerLayout drawerLayout) {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer((GravityCompat.START));
        }
    }

    public void ClickHome(View view){
        recreate();
    }
    public void ClickAboutUs(View view){
        redirectActivity(this,AboutUs.class);
    }
    public void ClickLogout(View view){
        logout(this);
    }

    public void logout(Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                //activity.finishAffinity();
                Intent i =new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
                //redirectActivity(this,MainActivity.class);
                //System.exit(0);

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog ,int which){
                dialog.dismiss();
            }
        });
        builder.show();
    }

    public static void redirectActivity(Activity activity,Class aClass) {
        Intent intent = new Intent(activity,aClass);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawerLayout);
    }







}



