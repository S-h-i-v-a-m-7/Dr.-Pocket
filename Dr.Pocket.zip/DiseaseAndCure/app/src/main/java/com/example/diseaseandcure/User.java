package com.example.diseaseandcure;

public class User {

    public String NAME,CONTACT,EMAIL,PASSWORD;

    public User(){

    }

    public User(String NAME, String CONTACT,String EMAIL,String PASSWORD){
        this.EMAIL = EMAIL;
        this.NAME = NAME;
        this.CONTACT = CONTACT;
        this.PASSWORD = PASSWORD;

    }
}
